import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import util.NewGpkiUtil;
import util.ShareGpki;

public class 한국도로교통공단_수시미필증빙파일이미지요청_AnytmIncmpPrufFileImageService {

	/**
	 * @param args
	 */
	// 이용기관의 네트워크망에 따라서 호출 host 정보가 다름. (네트워크망과 개발 or 운영의 용도에 따라서 해당하는 host로 설정)
	// 이용기관 : 행정망
	static String host = "10.188.225.94:29001"; // 개발(DEV)
//	static String host = "10.188.225.25:29001"; // 운영(OP)
			
	// 이용기관 : 인터넷
//	static String host = "116.67.73.153:39001"; // 개발(DEV)
//	static String host = "116.67.73.153:29001"; // 운영(OP)
		
	static String targetUrl = "http://"+host+"/piss/api/koroad/AnytmIncmpPrufFileImageService";
	
	static String method = "POST";
	
	//--------------Client Setting---------------
	//http Header Setting
	static String apiKey = "de4384bd1e2971bb773cfdff86bdd914a7135bc7171f40ee5f5909aea67a9b5a"; // 미래행공에서 발급된 API_KEY
	
	//http Body Setting
	static String charset = "UTF-8";

	//Gpki Setting
	static boolean useMockResponse = false;
	static boolean useGpki = true;
	static boolean useSign = true;
	static String gpkiCharset = "UTF-8";
	static String certServerId = ""; // 이용기관 인증서 ID
	static String targetServerId = "SVRB552061002"; // 보유기관 인증서 ID (도로교통공단)
	public static void main(String[] args) {
		한국도로교통공단_수시미필증빙파일이미지요청_AnytmIncmpPrufFileImageService.executeClient();
	}
	public static void executeClient(){
		String body = makeBody();
		String tx_id = getTx_Id();
		
		Map<String, String> requestHeader = new LinkedHashMap<String, String>();
		try {
			requestHeader.put("Host", InetAddress.getLocalHost().toString());
			requestHeader.put("User-Agent", "java-net-httpclient");
		} catch (Exception e) {
			e.printStackTrace();
		}
		requestHeader.put("Content-Type", "application/json; charset=UTF-8");
		requestHeader.put("Accept", "application/json");
		requestHeader.put("tx_id", tx_id);
		requestHeader.put("cert_server_id",certServerId);
		requestHeader.put("api_key", apiKey);
		requestHeader.put("gpki_yn", useGpki?"Y":"N");
		requestHeader.put("mock_yn", useMockResponse?"Y":"N");
		System.out.println("-------- Request Header -----------");
		for(Map.Entry<String, String> entry : requestHeader.entrySet()){
			System.out.println(entry.getKey() +  " : " + entry.getValue());
		}
		System.out.println("--------- Request Body ------------");
		System.out.println(body);
		
		System.out.println("----- Request Body Encrypt --------");
		// body 암호화
		String bodyEncrypt = null;
		try {
			if(useGpki){
				bodyEncrypt = gpkiEncrypt(body.toString());
			} else {
				bodyEncrypt = body.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Encrypt Body : " + bodyEncrypt);
		System.out.println("------------ Response -------------");
		
		한국도로교통공단_수시미필증빙파일이미지요청_AnytmIncmpPrufFileImageService.Response response = sendRequest(targetUrl, method, requestHeader, bodyEncrypt, charset);
		int responseCode = response.getResponseCode();
		Map<String, Object> responseHeader = response.getHeaderMap();
		String responseBody = response.getBody();
		System.out.println("-> response : " + response);
		System.out.println("-> responseCode : " + responseCode);
		System.out.println("-> responseHeader : " + responseHeader);
		System.out.println("-> responseBody : " + responseBody);
		
		System.out.println("----- Response Body Decrypt --------");
		try {
			// Body 복호화
			// responseMsg 복호화된 메시지를 Mapping하여 사용
			String responseMsg;
			if(responseCode == HttpURLConnection.HTTP_OK){
				responseMsg = gpkiDecrypt(responseBody);
			} else{
				String errorMessage = responseBody.split("\"message\":")[1];
				responseMsg = errorMessage.substring(1,errorMessage.length()-2);
				responseMsg = gpkiDecrypt(responseMsg);
			}
			System.out.println("-------- Response Message ---------");
			System.out.println(responseMsg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static Response sendRequest(String targetUrl, String method,
			Map<String, String> requestHeader, String body, String charset) {
		Response response = new Response();
		
		HttpURLConnection con = null;
		try {
			URL url = new URL(targetUrl);
			con = (HttpURLConnection) url.openConnection();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			for(Map.Entry<String, String> entry : requestHeader.entrySet()){
				con.setRequestProperty(entry.getKey(), entry.getValue());
			}
			con.setRequestMethod(method);
			con.setDefaultUseCaches(false);
			con.setAllowUserInteraction(false);
			con.setConnectTimeout(3000); con.setReadTimeout(15000);
			con.setDoInput(true);
			con.setDoOutput(true);
			
			con.connect();
			
			OutputStream os = null;
			OutputStreamWriter osw = null;
			StringBuffer responseBodyBuffer = new StringBuffer("");
			Map<String, Object> headerMap = response.getHeaderMap();
			
			os = con.getOutputStream();
			osw = new OutputStreamWriter(os, Charset.forName(charset));
			osw.write(body);
			osw.flush();
			
			int code = con.getResponseCode();
			response.setResponseCode(code);
			
			InputStream is = null;
			InputStreamReader isr = null;
			if(code == HttpURLConnection.HTTP_OK){
				is = con.getInputStream();
			}else{
				is = con.getErrorStream();
			}
			
			Map<String, List<String>> headerFields = con.getHeaderFields();
			for(Map.Entry<String, List<String>> headerEntry : headerFields.entrySet()){
				String key = headerEntry.getKey();
				List<String> values = headerEntry.getValue();
				if(values.size()<=1){
					headerMap.put(key, values.get(0));
				}else{
					headerMap.put(key, values);
				}
			}
			 try {
				 isr = new InputStreamReader(is, Charset.forName(charset));
				 int len = -1;
				 char[] ch = new char[32];
				 while((len = isr.read(ch, 0, ch.length))!= -1){
					 responseBodyBuffer.append(new String(ch, 0, len));
				 } 
				 response.setBody(responseBodyBuffer.toString());
			} catch (IOException e) {
			e.printStackTrace();
			}finally{
				isr.close();
				is.close();
				os.close();
				osw.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(con != null){
				con.disconnect();
			}
		}
		return response;
	}
	private static String makeBody() {
		StringBuffer sb = new StringBuffer();
		sb.append("{ \n");
		sb.append("	\"data\": [ \n");
		sb.append("		{ \n");
		sb.append("			\"FILE_ID\": \"1\", \n");
		sb.append("			\"FILE_SEQ\": \"2\" \n");
		sb.append("		} \n");
		sb.append("	] \n");
		sb.append("} \n");
		
		return sb.toString();
	}
	
	// 암호화
	private static String gpkiEncrypt(String str) throws Exception {
		NewGpkiUtil g = ShareGpki.getGpkiUtil(targetServerId);
		
		byte[] encrypted = g.encrypt(str.getBytes(gpkiCharset), targetServerId); // 암호화
		byte[] signed = encrypted;
		if(useSign) {
			signed = g.sign(encrypted); // digital sign
		}
		String encoded = g.encode(signed); // base64 encode
		return encoded;
	}
	
	// 복호화
	public static String gpkiDecrypt(String str) throws Exception {
		NewGpkiUtil g = ShareGpki.getGpkiUtil(targetServerId);
		byte[] decode = g.decode(str); // base64 decode
		byte[] validate = decode;
		if(useSign) {
			validate = g.validate(decode); 
		}
		byte[] decrypt = g.decrypt(validate); // 복호화
		String decrypted = new String(decrypt,gpkiCharset);
		return decrypted;
	}
	private static String getTx_Id() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS",Locale.KOREA);
		String cur = sdf.format(new Date());
		String transactionUniqueId = cur + keyGen(8);
		return transactionUniqueId;
	}
	private static Random r = new Random(System.currentTimeMillis());
	public static String keyGen(int length) {
		char[] key = new char[length];
		int tmp = 0;
		for (int i = 0; i < length; i++) {
			tmp = r.nextInt(3);
			if (tmp == 0)
				key[i] = (char) (r.nextInt(26) + 65);
			else if (tmp == 1)
				key[i] = (char) (r.nextInt(10) + 48);
			else if (tmp == 2)
				key[i] = (char) (r.nextInt(26) + 97);
			else {
				key[i] = (char) r.nextInt(256);
			}
		}
		return String.valueOf(key);
	}

	/*
	 * Response
	 */
	public static class Response {
		int responseCode;
		String body;
		Map<String, Object> headerMap = new LinkedHashMap<String, Object>();
		
		public int getResponseCode() {
			return responseCode;
		}
		public void setResponseCode(int responseCode) {
			this.responseCode = responseCode;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
		public Map<String, Object> getHeaderMap() {
			return headerMap;
		}
		public void setHeaderMap(Map<String, Object> headerMap) {
			this.headerMap = headerMap;
		}
	}
}
